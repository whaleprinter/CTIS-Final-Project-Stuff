/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CourseScheduler;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Roshan
 */
public class dataManager {
    static String delimiter = "~";
    public static void main(String[] args) {
        int crn;
        String subject;
        String courseName;
        int courseNumber;
        int section;
        String classDays;
        int startTime;
        int endTime;
        String location;
        
        
        ArrayList<course> courses = new ArrayList<>();
        try {
            Scanner courseReader = new Scanner(new File("courses.txt"));
            while (courseReader.hasNext()) {
                String currentLine = courseReader.nextLine();
                String[] splitString = currentLine.split(delimiter);
                crn = Integer.parseInt(splitString[0]);
                subject = splitString[1];
                courseName = splitString[2];
                courseNumber = Integer.parseInt(splitString[3]);
                section = Integer.parseInt(splitString[4]);
                classDays = splitString[5];
                startTime = Integer.parseInt(splitString[6]);
                endTime = Integer.parseInt(splitString[7]);
                location = splitString[8];
                
                course inputCourse = new course(crn, subject, courseName, courseNumber, section, classDays, startTime, endTime, location);
                courses.add(inputCourse);

            }
        }
        catch (FileNotFoundException ex) {
            System.out.println("File is missing!");
        }
        for (course courseInList : courses) {
            System.out.println(courseInList.toString());
        }
        
        
        
    }
   
}
