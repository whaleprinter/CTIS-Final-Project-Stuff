//Implements specification 1
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package applicantevaluation;

import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Roshan
 */
public class ApplicantEvaluation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<PositionApplicant> applicants = new ArrayList<PositionApplicant>();
        PositionApplicant testApplicant = new PositionApplicant("Roshan", "executive", 1, 100, 90, 80, 70, 60, 50, 40);
        applicants.add(testApplicant);
        System.out.println("The size of the list is " + applicants.size());
        /*
        String testString = "Will this work?";
        applicants.add(testString);
        */
        PositionApplicant testItem = applicants.get(0);
        System.out.println(testItem);
        applicants.remove(0);
        try {
            Scanner fileScan = new Scanner(new File("allTheApps.txt"));
            Random randGenerator = new Random();  
        while (fileScan.hasNext()) {  
            int applicantNum = randGenerator.nextInt(1000000);  
            int introCompProg = fileScan.nextInt();  
            int advCompProg = fileScan.nextInt();  
            int networking = fileScan.nextInt();  
            int databaseSystems = fileScan.nextInt();  
            int algorithms = fileScan.nextInt();  
            int operatingSystems = fileScan.nextInt();  
            double overallGPA = fileScan.nextDouble();  
            
            String name = "Applicant";  
            String position = "Programmer";  
            // Instantiating a new PositionApplicant
            PositionApplicant theApplicant = new PositionApplicant(name, position, applicantNum, introCompProg, advCompProg, networking, databaseSystems, algorithms, operatingSystems, overallGPA);
            applicants.add(theApplicant);  
        }
        System.out.println("The number of applicants is: " + applicants.size());    
            fileScan.close();
        } catch (FileNotFoundException ex) {
            System.out.println(ex);
            System.exit(0);
        }
        int countApproved1 = 0;
        
        for (PositionApplicant app : applicants) {
            if (app.analyze_applicant1()) {
                countApproved1 += 1;
            }
        }
        System.out.println("The number of approved applicants is: " + countApproved1);
        double numberOfApplicants1 = applicants.size();
        double percent1 = (((double) countApproved1) / numberOfApplicants1) * 100;
        System.out.println("The Percentage of Applicants who were Accepted is: " + percent1);
        
        int countApproved2 = 0;
        for (PositionApplicant app : applicants) {
            if (app.analyze_applicant2()) {
                countApproved2 += 1;
            }
        }
        System.out.println("The number of approved applicants is: " + countApproved2);
        double numberOfApplicants2 = applicants.size();
        double percent2 = (((double) countApproved2) / numberOfApplicants2) * 100;
        System.out.println("The Percentage of Applicants who were Accepted is: " + percent2);
        
        int countApproved3 = 0;
        for (PositionApplicant app : applicants) {
            if (app.analyze_applicant3()) {
                countApproved3 += 1;
            }
        }
        System.out.println("The number of approved applicants is: " + countApproved3);
        double numberOfApplicants3 = applicants.size();
        double percent3 = (((double) countApproved3) / numberOfApplicants3) * 100;
        System.out.println("The Percentage of Applicants who were Accepted is: " + percent3);
        
        int countApproved4 = 0;
        for (PositionApplicant app : applicants) {
            if (app.analyze_applicant4()) {
                countApproved4 += 1;
            }
        }
        System.out.println("The number of approved applicants is: " + countApproved4);
        double numberOfApplicants4 = applicants.size();
        double percent4 = (((double) countApproved4) / numberOfApplicants4) * 100;
        System.out.println("The Percentage of Applicants who were Accepted is: " + percent4);
        
        int countApproved5 = 0;
        for (PositionApplicant app : applicants) {
            if (app.analyze_applicant5()) {
                countApproved5 += 1;
            }
        }
        System.out.println("The number of approved applicants is: " + countApproved5);
        double numberOfApplicants5 = applicants.size();
        double percent5 = (((double) countApproved5) / numberOfApplicants5) * 100;
        System.out.println("The Percentage of Applicants who were Accepted is: " + percent5);
        
        
        /*
        
        Chances are that this new machine-learning job is in a trailblazing company in which there are few members on the team. Like many popular tech companies out there, jobs 
        are limited and applicants are in the thousands. Thus, very few people actually get accepted--only the most qualified of the qualified are invited to interviews and only the best of those 
        are accepted. Therefore, I'm aiming for roughly 1%-3%of the applicants to be accepted, especially since interviewing all the selected applicants with my very small team of employees will be difficult in its own right. 
        
        
        From this modified method, we see that over 200 applicants still need to be interviewed. While that seems like a small number compared to the number of applicants, it's still an enormous number! Considering that each selected applicant takes roughly 45 minutes total to interview 
        and process, that's already 150 hours worth of interviewing alone! At least we're able to use a computer to narrow down the number of applicants in the first place.
        */
        
        int countApproved = 0;
        for (PositionApplicant app : applicants) {
            if (app.analyze_applicant6()) {
                countApproved += 1;
            }
        }
        System.out.println("The number of approved applicants is: " + countApproved);
        double numberOfApplicants = applicants.size();
        double percent = (((double) countApproved) / numberOfApplicants) * 100;
        System.out.println("The Percentage of Applicants who were Accepted is: " + percent);
        
        
        //LAB 12
        JFrame appWindow = new JFrame("Applicants"); 
        appWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        
        //Implements specification 11
        ApplicantsPanel appPanel = new ApplicantsPanel(applicants); 
        appPanel.setBackground(Color.blue);
        
        //Implements specification 11
        ApplicantsPanel appPanel1 = new ApplicantsPanel(applicants);
        appPanel1.setBackground(Color.red);
        
        JPanel appsPanel = new JPanel();
        appsPanel.add(appPanel);
        appsPanel.add(appPanel1);
        appWindow.add(appsPanel); 
        
        appWindow.pack(); 
        appWindow.setVisible(true);
    }
}
