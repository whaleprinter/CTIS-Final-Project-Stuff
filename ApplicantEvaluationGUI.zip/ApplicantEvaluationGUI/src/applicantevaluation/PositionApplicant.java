//Implements specification 1
package applicantevaluation;

import java.util.ArrayList;
import java.util.List;

public class PositionApplicant {
    private String applicantName; //Implements specification 2
    private String positionName;
    private int applicantNumber;
    private int introCompProg;
    private int advCompProg;
    private int networking;
    private int databaseSystems;
    private int algorithms;
    private int operatingSystems;
    private double gpa;
    
    //Implements specification 4
    /**
     * Constructor with one attribute
     * @param applicantName 
     */
    public PositionApplicant(String applicantName) {
        this.applicantName = applicantName;
    }
   
    //Implements specification 4
    /**
     * Constructor for the PositionApplicant
     * @param applicantName
     * @param positionName
     * @param applicantNumber
     * @param introCompProg
     * @param advCompProg
     * @param networking
     * @param databaseSystems
     * @param algorithms
     * @param operatingSystems
     * @param gpa 
     */
    public PositionApplicant(String applicantName, String positionName, int applicantNumber, int introCompProg, int advCompProg, int networking, int databaseSystems, int algorithms, int operatingSystems, double gpa) {
        this.applicantName = applicantName;
        this.positionName = positionName;
        this.applicantNumber = applicantNumber;
        this.introCompProg = introCompProg;
        this.advCompProg = advCompProg;
        this.networking = networking;
        this.databaseSystems = databaseSystems;
        this.algorithms = algorithms;
        this.operatingSystems = operatingSystems;
        this.gpa = gpa;
    }

    
    //Expand to see Getters and Setters
 // <editor-fold defaultstate="collapsed" desc="Getters and Setters"> 

    public String getApplicantName() {
        return applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }
   
    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }
    
    public int getApplicantNumber() {
        return applicantNumber;
    }

    public void setApplicantNumber(int applicantNumber) {
        this.applicantNumber = applicantNumber;
    }

    public int getIntroCompProg() {
        return introCompProg;
    }

    public void setIntroCompProg(int introCompProg) {
        this.introCompProg = introCompProg;
    }

    public int getAdvCompProg() {
        return advCompProg;
    }

    public void setAdvCompProg(int advCompProg) {
        this.advCompProg = advCompProg;
    }

    public int getNetworking() {
        return networking;
    }

    public void setNetworking(int networking) {
        this.networking = networking;
    }

    public int getDatabaseSystems() {
        return databaseSystems;
    }

    public void setDatabaseSystems(int databaseSystems) {
        this.databaseSystems = databaseSystems;
    }

    public int getAlgorithms() {
        return algorithms;
    }

    public void setAlgorithms(int algorithms) {
        this.algorithms = algorithms;
    }
    
    public int getOperatingSystems() {
        return operatingSystems;
    }

    public void setOperatingSystems(int operatingSystems) {
        this.operatingSystems = operatingSystems;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }
    // </editor-fold> //Implements specification 3
    
    /**
     * Average Calculator
     * @return averageScore
     */
    public double calculateAverageScore(){
        double averageScore;
        averageScore = (introCompProg + advCompProg + networking + databaseSystems + operatingSystems + algorithms) / 6;
        return averageScore;
    }
    
    /**
     * Standard Deviation Calculator
     * @return stdDev
     */
    public double stdDev() {
        //Calculating Average
        double average = this.calculateAverageScore();
                
        //Calculating the standard deviation
        double termOne = Math.pow(introCompProg - average, 2);
        double termTwo = Math.pow(advCompProg - average, 2);
        double termThree = Math.pow(networking - average, 2);
        double termFour = Math.pow(databaseSystems - average, 2);
        double termFive = Math.pow(operatingSystems - average, 2);
        double termSix = Math.pow(algorithms - average, 2);
        
        double stdDev = Math.sqrt((termOne + termTwo + termThree + termFour +termFive + termSix)/(6));
        
        return stdDev;
    }
    
    
    //Implements specification 5
    /**
     * Analyze based off of intro grade
     * @return 
     */
    public boolean analyze_applicant1(){
        boolean accept;
        accept = introCompProg > 80;
        return accept;
    }
    
    /**
     * Analyze based off of intro and advanced grades
     * @return 
     */
    public boolean analyze_applicant2(){
        boolean accept;
        accept = (introCompProg > 85) && (advCompProg > 85);
        return accept;
    }

    /**
     * Analyze based off of high GPA and high average computing score
     * @return 
     */
    public boolean analyze_applicant3(){
        boolean consider;
        if ((gpa > 90) || (calculateAverageScore() > 85)){
            consider = true;
        }
        else {
            consider = false;
        }
        return consider;
              
    }
    
    /**
     * Analyze based off high GPA and high algorithms score
     * @return 
     */
    public boolean analyze_applicant4(){
        boolean consider;
        
        /*
        We want our applicant to be very good overall but also be specialized in algorithms, since they would be 
        implementing machine learning systems on the job. We're assuming that being good in algorithms implies competence
        in the other basic fields (introductory and advanced computer programming, in particular)
        8?
        */
        if ((gpa > 75) && (algorithms >= 80)) {
            consider = true;          
        }
        else {
            consider = false;
        }
        return consider;
    }
    
    /**
     * Analyze based off of high Average and high Standard Deviation
     * @return 
     */
    public boolean analyze_applicant5(){
        boolean consider;
        /*
        For this second method, we are checking to see whether the average grade in computing classes is higher than a certain
        value AND that there is not much spread in those gradce. For example, we want to ensure that the applicant has 
        consistently high grades across all their classes, so we take the standard deviation that make sure that it is (relatively) small
        */
        if ((calculateAverageScore() > 85) && (stdDev() < 10)){
            consider = true;
        }
        else{
            consider = false;
        }
        return consider;
    }
    
    /**
     * Analyze based off of very high average score and high standard deviation
     * @return 
     */
    public boolean analyze_applicant6(){
        boolean consider;
        /*
        Similar to the method above, this method uses the average score along with the standard deviation to pick out only the best applicants (grade-wise). The grades overall must be very high and the spread of scores must be minimal to ensure that the
        applicant demonstates consistent performance in their classes.
        */
        if ((calculateAverageScore() > 97) && (stdDev() < 5)){
            consider = true;
        }
        else{
            consider = false;
        }
        return consider;
    }
    

    /**
     * toString() method
     * @return 
     */
    @Override
    public String toString() {
        return "Applicant Name: " + applicantName + "\nPosition Name: " + positionName + "\nApplicant Number: " + applicantNumber + "\nIntro Comp Prog: " + introCompProg + "\nAdv Comp Prog: " + advCompProg + "\nNetworking: " + networking + "\nDatabase Systems: " + databaseSystems + "\nOperating Systems: " + operatingSystems + "\nAlgorithms: " + algorithms + "\nGPA: " + gpa;
    }
    
    
}


    

